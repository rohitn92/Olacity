package com.ola.moments;

import org.json.JSONObject;

public interface onTaskComplete {
	void onTaskCompleted(String out);
	void onTaskCompleted(JSONObject out);
}
