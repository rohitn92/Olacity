package com.ola.moments;

import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Contact extends ListActivity implements onTaskComplete{
	AsyncPost post;
	Contacts contact;
	ArrayAdapter<String> adapter;
	public static final String URL = "http://mitrevels.in/app_roll/gcm_server_php/send_users.php";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		String values [] = new String[]{"+918409119848", "+919886507948"};
		setContentView(R.layout.activity_contact);
		adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, values);
		setListAdapter(adapter);
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("id", "123");
		data.put("number", "123456789");
		contact = new Contacts(this);
		post = new AsyncPost(data);
		post.onComplete = this;
		post.execute(URL);
		//TextView tv = (TextView) findViewById(R.id.text2);
		//tv.setText(contact.getContactName("+918409119848"));
	}
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		String item = (String) getListAdapter().getItem(position);
	    Toast.makeText(this, item + " selected", Toast.LENGTH_LONG).show();
	}
	@Override
	public void onTaskCompleted(String out) {
		Log.e("OUTPUT", out);
		//TextView t = (TextView) findViewById(R.id.text);
		String result [] = out.split("|");
		String name[] = new String[200];
		for(int i = 0; i < name.length; i++) {
			name[i] = contact.getContactName(result[i]+"");
		}
		adapter.addAll(name);
		adapter.notifyDataSetChanged();
		
	}
	@Override
	public void onTaskCompleted(JSONObject out) {
		// TODO Auto-generated method stub
		
	}
}
