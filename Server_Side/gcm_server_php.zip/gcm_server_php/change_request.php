<?php
$username = "system_admin";
$password = "Revels13";
$db = "gcm";
$conn = mysqli_connect("localhost",$username,$password,$db) or die("Failed to connect to database");


        	//save the details of coordinates to the database.
//        	extract($_POST);
	$q="UPDATE `request` SET `flag`='1' WHERE `device_id`='".$_POST['device_id']."' and `event_id`='".$_POST['event_id']."'";
//if(isset($_POST['device_id'])){
//        	$q="UPDATE `request` SET `flag`='1' WHERE `device_id`='".$_POST['device_id']."'";
//        	$q="UPDATE `request` SET `flag`='1' WHERE `device_id`='1'";
        	echo ''.$q;
        	$res = mysqli_query($conn, $q) or die (mysqli_error($conn));
  //      	}
        ?>
    <!--     <form action="change_request.php" method="post">
        <input type="text" id="device_id" name="device_id"> 
                <input type="text" id="event_id">
                <input type="submit" id="submit" name="submit">
                </form>-->
        