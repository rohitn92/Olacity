<?php
include_once 'db_functions.php';
        $db = new DB_Functions();
        $users = $db->getAllUsers();
if(isset($_POST['message']))
{
	sendPushNotification(1);
	echo "I a here ";
}
?>
<script>
function sendPushNotification(id){
                var data = $('form#'+id).serialize();
                $('form#'+id).unbind('submit');                
                $.ajax({
                    url: "send_message.php",
                    type: 'GET',
                    data: data,
                    beforeSend: function() {
                        
                    },
                    success: function(data, textStatus, xhr) {
                          $('.txt_message').val("");
                    },
                    error: function(xhr, textStatus, errorThrown) {
                        
                    }
                });
                return false;
            }
</script>
<?php
if(isset($_POST['yo']))
{
 echo "Here ";
//create array of data to be posted
$post_data['message'] = 'Hi';
$post_data['regId'] = 'APA91bEzwrThjttkHjXMEsvS2Doiyz9c3XcBoXLGXSmGDHbaxtN53IxnQHEhmW6qsQw76JbDqD9Q3gOImstVMrf0cJaIL6F3-levvSVZSy-pSl-waW4iScH8arl6dIMdrVpC_99d_qKY4h1cJkNTd32W5diRMjksmVBBz6S22o8rTeRtzhy3dXo';
 
//traverse array and prepare data for posting (key1=value1)
foreach ( $post_data as $key => $value) {
    $post_items[] = $key . '=' . $value;
}
 
//create the final string to be posted using implode()
$post_string = implode ('&', $post_items);
 
//we also need to add a question mark at the beginning of the string
$post_string = '?' . $post_string;
 
//we are going to need the length of the data string
$data_length = strlen($post_string);
 
//let's open the connection
$connection = fsockopen('www.mitrevels.in', 80); 
 
//sending the data
fputs($connection, "POST  /curl_try.php  HTTP/1.1\r\n"); 
fputs($connection, "Host:  www.mitrevels.in/app_roll/gcm_server_php \r\n"); 
fputs($connection, 
    "Content-Type: application/x-www-form-urlencoded\r\n"); 
fputs($connection, "Content-Length: $data_length\r\n"); 
fputs($connection, "Connection: close\r\n\r\n"); 
fputs($connection, $post_string); 
 
//closing the connection
fclose($connection);
}
 
?>
<form action="curl_try.php" method="post">
<input type="text" name="yo" id="yo">
<input type="submit" name="submit" id="submit">
</form>