<?php
class main {
	protected $db_hostname = "localhost"; // mysql hostname
	protected $db_username = "system_admin"; // mysql username
	protected $db_password = "Revels13"; // mysql password
	protected $db_name = "gcm"; // mysql database name
	protected $table="gcm_users";
	function __construct() {
		self::con ();
	}
	function __destruct() {
		self::cl_con ();
	}
	protected function con() { // this function establishes the connection
		$this->con = mysqli_connect ( $this->db_hostname, $this->db_username, $this->db_password ) or die ();
		self::create_db();
	}
	protected function cl_con() { // this function terminates the connection
		mysqli_close ( $this->con );
	}
	protected function create_db() { // creates database
		// $q = "CREATE DATABASE IF NOT EXISTS $this->db_name";
		// mysqli_query ( $this->con, $q ) or die ( mysqli_error ( $this->con ) );
		mysqli_select_db ( $this->con, $this->db_name ) or die ( mysqli_error ( $this->con ) );
	}
	public function printJson(){
	$q="SELECT MAX(`id`) as mas FROM  `gcm_users`";
		$result=mysqli_query($this->con,$q) or die(mysqli_error($this->con));
		$row=mysqli_fetch_array($result);
		echo ''.$row['mas'];
//		echo 'h';
	}
}
$main = new main ();
echo $main->printJson();
?>