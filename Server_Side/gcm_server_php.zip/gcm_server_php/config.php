<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "system_admin");
define("DB_PASSWORD", "Revels13");
define("DB_DATABASE", "gcm");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyAVyiruOCTO9LwfegcbrPNUOuEPQGK9tmE"); // Place your Google API Key
?>