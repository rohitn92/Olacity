<?php

$username = "system_admin";
$password = "Revels13";
$db = "gcm";
$conn = mysqli_connect("localhost",$username,$password,$db) or die("Failed to connect to database");


        	//save the details of coordinates to the database.
     	//extract($_POST);
//        	$pieces = $ids;//explode(",", $ids);
echo ''.$ids;
        	$q1="select `id` from `gcm_users` where `email`='".$_POST['ids']."'";
        	echo ''.$q1;
        	$res1 = mysqli_query($conn, $q1) or die (mysqli_error($conn));
        	while($row=mysqli_fetch_array($res1)){
        	$q="INSERT INTO `request`(`device_id`,`event_id`,`flag`, `host_id`) VALUES ('".$row['id']."','".$_POST['event_id']."','0','".$_POST['device_id']."')";
        	$res = mysqli_query($conn, $q) or die (mysqli_error($conn));
        	}
        	echo "hi";
        	
//}
        ?>
        <form action="add_request.php" method="post">
        <input type="text" id="device_id"> 
                <input type="text" id="event_id">
                <input type="text" id="ids">
                
                <input type="submit" id="submit" name="submit">
                </form>