<?php
$username = "system_admin";
$password = "Revels13";
$db = "gcm";
$conn = mysqli_connect("localhost",$username,$password,$db) or die("Failed to connect to database");

if(isset($_POST['id'])){
        	//save the details of coordinates to the database.
        	extract($_POST);
        	$q1="select * from `coord` where `device_id`='".$id."'";
        	$res1 = mysqli_query($conn, $q1) or die (mysqli_error($conn));
		$row=mysqli_fetch_array($res1);
		if( mysqli_num_rows($res1)==1)
		{
			$q2="UPDATE `coord` SET `lat`='".$lat."',`long`='".$long."' WHERE `device_id`='".$id."'";
        	$res2 = mysqli_query($conn, $q2) or die (mysqli_error($conn));			
		}else{
        	
        	$q="INSERT INTO `coord`(`device_id`, `lat`, `long`) VALUES ('".$id."','".$lat."','".$long."')";
        	$res = mysqli_query($conn, $q) or die (mysqli_error($conn));
        	echo $id;
        	
        	}
        	}
        	
        	
        	
        	///now printing the json
        	class main {
	protected $db_hostname = "localhost"; // mysql hostname
	protected $db_username = "system_admin"; // mysql username
	protected $db_password = "Revels13"; // mysql password
	protected $db_name = "gcm"; // mysql database name
	protected $table="coord";
	function __construct() {
		self::con ();
	}
	function __destruct() {
		self::cl_con ();
	}
	protected function con() { // this function establishes the connection
		$this->con = mysqli_connect ( $this->db_hostname, $this->db_username, $this->db_password ) or die ();
		self::create_db();
	}
	protected function cl_con() { // this function terminates the connection
		mysqli_close ( $this->con );
	}
	protected function create_db() { // creates database
		// $q = "CREATE DATABASE IF NOT EXISTS $this->db_name";
		// mysqli_query ( $this->con, $q ) or die ( mysqli_error ( $this->con ) );
		mysqli_select_db ( $this->con, $this->db_name ) or die ( mysqli_error ( $this->con ) );
	}
	public function printJson(){
		$q="SELECT * FROM $this->table";
		$result=mysqli_query($this->con,$q) or die(mysqli_error($this->con));
		$num=mysqli_num_rows($result);
		$total=0;
		$json=array();
		if($num)
		{
			for($i=0;$i<$num;$i++)
			{
				$row=mysqli_fetch_row($result);
				$id=$row[0];
				$lat=$row[1];
				$long=$row[2];
				$json[]=array(
						"id" => $id,
						"lat" => $lat,
						"long" => $long
					);
			}
		}
		$json=array("devices" => $json);
		echo json_encode($json);
	}
}
$main = new main ();
echo $main->printJson();
        ?>